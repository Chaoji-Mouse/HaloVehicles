package com.cmhh.halovecs.entity.vehicle;

import com.atsuishio.superbwarfare.entity.vehicle.base.GeoVehicleEntity;
import com.atsuishio.superbwarfare.entity.vehicle.damage.DamageModifier;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;



public class M274Entity extends GeoVehicleEntity {

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public M274Entity(EntityType<M274Entity> type, Level world) {
        super(type, world);
    }

    @Override
    public DamageModifier getDamageModifier() {
        return super.getDamageModifier()
                .custom((source, damage) -> getSourceAngle(source, 0.25f) * damage);
    }

    // ========== 新增：覆盖转向相关方法 ==========
    @Override
    public void setRudderRot(float rudderRot) {
        // 放大输入的角度值
        float amplifiedRudder = rudderRot * 1.5f; // 增加100%(并非)
        
        // 调用父类方法，但使用放宽的限制
        float clamped = Mth.clamp(amplifiedRudder, -1.5f, 1.5f); // 原限制：-0.8f, 0.8f
        super.setRudderRot(clamped);
    }
    
}
