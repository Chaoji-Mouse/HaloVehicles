package com.cmhh.halovecs.mixin;

import com.atsuishio.superbwarfare.entity.vehicle.base.VehicleEntity;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * 通用Mixin：拦截所有Mth.clamp调用
 */
@Mixin(targets = {
    "com.atsuishio.superbwarfare.entity.vehicle.utils.VehicleEngineUtils"
})
public class VehicleEngineUtilsMixin {
    
    /**
     * 拦截所有Mth.clamp调用，通过上下文判断是否是方向舵限制
     */
    @Redirect(
        method = "*", // 匹配所有方法
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/util/Mth;clamp(FFF)F"
        )
    )
    private static float redirectAnyClamp(float value, float min, float max, VehicleEntity vehicle) {
        // 通过参数值判断是否是方向舵限制（原版值：-0.8f, 0.8f）
        if (Math.abs(min - (-0.8f)) < 0.01f && Math.abs(max - 0.8f) < 0.01f) {
            // 这很可能是方向舵限制
            String vehicleId = vehicle != null ? vehicle.getEncodeId() : null;
            
            if (vehicleId == null) {
                return Mth.clamp(value, min, max);
            }
            
            // 根据载具ID修改限制
            switch (vehicleId) {
                case "halovecs:m274":
                    return Mth.clamp(value, -1.2f, 1.2f);
                default:
                    return Mth.clamp(value, min, max);
            }
        }
        
        // 其他clamp调用保持原样
        return Mth.clamp(value, min, max);
    }
}
