package com.cmhh.halovecs.init;

import com.cmhh.halovecs.Halovecs;
import com.cmhh.halovecs.client.renderer.entity.M12Renderer;
import com.cmhh.halovecs.client.renderer.entity.M12gauRenderer;
import com.cmhh.halovecs.client.renderer.entity.M12hmgRenderer;
import com.cmhh.halovecs.client.renderer.entity.M12rocRenderer;
import com.cmhh.halovecs.client.renderer.entity.M12traRenderer;
import com.cmhh.halovecs.client.renderer.entity.M274Renderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = Halovecs.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ModEntityRenderers {

    @SubscribeEvent
    public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
        // 注册 M12 实体渲染器
        event.registerEntityRenderer(ModEntities.M12.get(), M12Renderer::new);
        // 注册 M12hmg 实体渲染器
        event.registerEntityRenderer(ModEntities.M12hmg.get(), M12hmgRenderer::new);
        // 注册 M12roc 实体渲染器
        event.registerEntityRenderer(ModEntities.M12roc.get(), M12rocRenderer::new);
        // 注册 M12gau 实体渲染器
        event.registerEntityRenderer(ModEntities.M12gau.get(), M12gauRenderer::new);
        // 注册 M12tra 实体渲染器
        event.registerEntityRenderer(ModEntities.M12tra.get(), M12traRenderer::new);
        // 注册 M274 实体渲染器
        event.registerEntityRenderer(ModEntities.M274.get(), M274Renderer::new);
    }
}
