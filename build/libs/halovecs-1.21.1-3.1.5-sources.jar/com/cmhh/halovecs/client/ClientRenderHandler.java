package com.cmhh.halovecs.client;

import com.cmhh.halovecs.client.overlay.VehicleCrosshairOverlay;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientRenderHandler {

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiLayersEvent event) {
        // 注册车辆准心覆盖层
        // 我们将其注册在较低的位置，确保它在其他HUD元素之上
        event.registerBelowAll(VehicleCrosshairOverlay.ID, new VehicleCrosshairOverlay());
    }
}
