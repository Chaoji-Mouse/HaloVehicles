package com.cmhh.halovecs.entity.vehicle;

import com.atsuishio.superbwarfare.entity.vehicle.base.GeoVehicleEntity;
import com.atsuishio.superbwarfare.entity.vehicle.damage.DamageModifier;
import com.cmhh.halovecs.entity.vehicle.utils.M274VehicleEngineUtils;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;



public class M274Entity extends GeoVehicleEntity {

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private static final float CUSTOM_RUDDER_LIMIT = 2f; // 原值0.8f

    private static final float WHEEL_VISUAL_LIMIT = 0.5f;

    public M274Entity(EntityType<M274Entity> type, Level world) {
        super(type, world);
    }

    @Override
    public DamageModifier getDamageModifier() {
        return super.getDamageModifier()
                .custom((source, damage) -> getSourceAngle(source, 0.25f) * damage);
    }

    @Override
    public void setRudderRot(float rudderRot) {
        // 计算新的方向舵角度（复制SuperbWarfare逻辑）
        float newRudderRot = rudderRot - this.getEntityData().get(DELTA_ROT);
        
        // 关键修改：使用自定义的限制值
        // 注意：Mth.clamp参数顺序是(value, min, max)
        float clampedRudder = net.minecraft.util.Mth.clamp(
            newRudderRot, 
            -CUSTOM_RUDDER_LIMIT,  // 最小值（左转限制）
            CUSTOM_RUDDER_LIMIT     // 最大值（右转限制）
        );
        
        // 保持原版缩放因子0.75f
        float scaledRudder = clampedRudder * 0.75f;
        
        // 调用父类方法
        super.setRudderRot(scaledRudder);
    }

    @Override
    public void tick() {
        // 先调用父类tick，执行原版逻辑
        super.tick();
        
        // 在服务端执行自定义车轮外观控制
        if (!this.level().isClientSide() && this.getEngineInfo() instanceof com.atsuishio.superbwarfare.data.vehicle.subdata.EngineInfo.Wheel engineInfo) {
            controlWheelVisuals(engineInfo);
        }
    }
    
    /**
     * 控制车轮外观角度，限制在0.8f以内
     */
    private void controlWheelVisuals(com.atsuishio.superbwarfare.data.vehicle.subdata.EngineInfo.Wheel engineInfo) {
        // 获取当前方向舵角度
        float currentRudder = this.getRudderRot();
        
        // 将方向舵角度限制在视觉范围内
        float visualRudder = Mth.clamp(currentRudder, -WHEEL_VISUAL_LIMIT, WHEEL_VISUAL_LIMIT);
        
        // 计算车轮差速（使用原版wheelDifferential）
        double wheelDifferential = engineInfo.wheelDifferential;
        float wheelDiff = (float) (wheelDifferential * this.getEntityData().get(DELTA_ROT));
        wheelDiff = Mth.clamp(wheelDiff, -5f, 5f); // 保持原限制
        
        // 计算车轮旋转速度
        double wheelRotSpeed = engineInfo.wheelRotSpeed;
        double movementLength = this.getDeltaMovement().length();
        
        // 应用车轮旋转 - 使用限制后的视觉方向舵角度
        float leftWheelRot = (float) ((this.getLeftWheelRot() - wheelRotSpeed) 
            + wheelDiff * movementLength * (visualRudder / WHEEL_VISUAL_LIMIT));
        
        float rightWheelRot = (float) ((this.getRightWheelRot() - wheelRotSpeed) 
            - wheelDiff * movementLength * (visualRudder / WHEEL_VISUAL_LIMIT));
        
        // 设置车轮旋转角度
        this.setLeftWheelRot(leftWheelRot);
        this.setRightWheelRot(rightWheelRot);
    }


    
    
}
