package com.cmhh.halovecs.mixin;

import com.atsuishio.superbwarfare.entity.vehicle.utils.VehicleEngineUtils;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(VehicleEngineUtils.class)
public class VehicleEngineUtilsMixin {
    
    /**
     * 修改WheelDifferential的正向最大限制值（原为5.0f）
     * 添加 remap = false 避免混淆映射问题
     */
    @ModifyConstant(
        method = "wheelEngine(Lcom/atsuishio/superbwarfare/entity/vehicle/base/VehicleEntity;Lcom/atsuishio/superbwarfare/data/vehicle/subdata/EngineInfo$Wheel;)V",
        constant = @Constant(floatValue = 5.0f),
        remap = false  // 关键修复：禁用重映射
    )
    private static float halovecs$modifyWheelDiffPositiveLimit(float original) {
        // 暂时修改所有载具为50.0f
        // 后续可以添加逻辑来识别特定载具
        return 50.0f;
    }
    
    /**
     * 修改WheelDifferential的负向最大限制值（原为-5.0f）
     * 添加 remap = false 避免混淆映射问题
     */
    @ModifyConstant(
        method = "wheelEngine(Lcom/atsuishio/superbwarfare/entity/vehicle/base/VehicleEntity;Lcom/atsuishio/superbwarfare/data/vehicle/subdata/EngineInfo$Wheel;)V",
        constant = @Constant(floatValue = -5.0f),
        remap = false  // 关键修复：禁用重映射
    )
    private static float halovecs$modifyWheelDiffNegativeLimit(float original) {
        // 暂时修改所有载具为-50.0f
        return -50.0f;
    }
}
