package com.cmhh.halovecs.entity.vehicle;

import com.atsuishio.superbwarfare.entity.vehicle.base.GeoVehicleEntity;
import com.atsuishio.superbwarfare.entity.vehicle.damage.DamageModifier;
import com.cmhh.halovecs.entity.vehicle.utils.M274VehicleEngineUtils;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;



public class M274Entity extends GeoVehicleEntity {

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public M274Entity(EntityType<M274Entity> type, Level world) {
        super(type, world);
    }

    @Override
    public DamageModifier getDamageModifier() {
        return super.getDamageModifier()
                .custom((source, damage) -> getSourceAngle(source, 0.25f) * damage);
    }

    // ========== 核心修改：覆盖tick方法 ==========
    
    @Override
    public void tick() {
        super.tick();
        
        // 如果这是M274载具，使用自定义转向计算
        if (!this.level().isClientSide() && this.getEngineInfo() instanceof com.atsuishio.superbwarfare.data.vehicle.subdata.EngineInfo.Wheel wheelInfo) {
            // 使用自定义的转向计算
            M274VehicleEngineUtils.wheelEngineForM274(this, wheelInfo);
        }
    }
    
}
